import * as fs from "fs"
import os from "os"
import path from "path"

let platform = os.platform();

export class CntEvent {
    private cnt: number;
    private emptyEvent: any[];
    constructor() {
        this.cnt = 0;
        this.emptyEvent = [];
        this.encount = this.encount.bind(this);
        this.decount = this.decount.bind(this);
        this.add = this.add.bind(this);
    }

    encount(delta = 1) {
        this.cnt += delta;
    }

    decount() {
        if (this.cnt > 0) --this.cnt;
        if (this.cnt == 0) {
            for (let info of this.emptyEvent) info[0](...info[1]);
            this.emptyEvent = [];
        }
    }

    add(cb:any, ...attach:any[]) {
        this.emptyEvent.push([cb, attach]);
    }

    check(cb:any, ...attach:any[]) {
        if (this.cnt == 0) cb(...attach);
        else this.add(cb, ...attach);
    }
}

class LimitedRunner {
    private limit: any;
    private cnt: number;
    private funcs: any[];
    constructor(limit:any) {
        this.limit = limit;
        this.cnt = 0;
        this.funcs = [];
    }

    run(func:any) {
        if (this.cnt < this.limit) {
            this.cnt++;
            setTimeout(func, 0);
        } else {
            this.funcs.push(func);
        }
    }

    done() {
        if (this.cnt > 0) this.cnt--;
        if (this.funcs.length > 0) {
            this.cnt++;
            setTimeout(this.funcs.shift(), 0);
        }
    }

    runWithCb(func:any, ...args:any[]) {
        let cb = args.pop() as any, self = this;

        const agent = (...args: any[]) => {
            self.done();
            return cb.apply(this, args);
        }

        args.push(agent);
        this.run(() => func(...args));
    }
}

let ioEvent = new CntEvent;
let ioLimit = new LimitedRunner(4096);

export const addIO=ioEvent.add

export function mkdirs(dir:any, cb:any) {
    ioLimit.runWithCb(fs.stat.bind(fs), dir, (err:any, stats:any) => {
        if (err) mkdirs(path.dirname(dir), () => fs.mkdir(dir, cb));
        else if (stats.isFile()) throw Error(dir + " was created as a file, so we cannot put file into it.");
        else cb();
    });
}

export function save(name:any, content:any) {
    ioEvent.encount();
    mkdirs(path.dirname(name), () => ioLimit.runWithCb(fs.writeFile.bind(fs), name, content, (err:any) => {
        if (err) {
            if (platform.indexOf('win') != -1) {
              console.log('Save file error: ' + err);
            } else {
              throw Error('Save file error: ' + err);
            }
        }
        ioEvent.decount();
    }));
}

export function get(name:any, cb:any, opt = {encoding: 'utf8'}) {
    ioEvent.encount();
    ioLimit.runWithCb(fs.readFile.bind(fs), name, opt, (err:any, data:any) => {
        if (err) throw Error("Read file error: " + err);
        else cb(data);
        ioEvent.decount();
    });
}

export function del(name:any) {
    ioEvent.encount();
    ioLimit.runWithCb(fs.unlink.bind(fs), name, ioEvent.decount);
}

export function changeExt(name:any, ext = "") {
    return name.slice(0, name.lastIndexOf(".")) + ext;
}

export function scanDirByExt(dir:any, ext:any, cb:any) {
    let result:any[] = [], scanEvent = new CntEvent;

    function helper(dir:any) {
        scanEvent.encount();
        ioLimit.runWithCb(fs.readdir.bind(fs), dir, (err:any, files:any) => {
            if (err) throw Error("Scan dir error: " + err);
            for (let file of files) {
                scanEvent.encount();
                let name = path.resolve(dir, file);
                fs.stat(name, (err, stats) => {
                    if (err) throw Error("Scan dir error: " + err);
                    if (stats.isDirectory()) helper(name);
                    else if (stats.isFile() && name.endsWith(ext)) result.push(name);
                    scanEvent.decount();
                });
            }
            scanEvent.decount();
        });
    }

    scanEvent.add(cb, result);
    helper(dir);
}

export function toDir(to:any, from:any) {//get relative path without posix/win32 problem
    if (from[0] === ".") from = from.slice(1);
    if (to[0] === ".") to = to.slice(1);
    from = from.replace(/\\/g, '/');
    to = to.replace(/\\/g, '/');
    let a = Math.min(to.length, from.length);
    for (let i = 1, m = Math.min(to.length, from.length); i <= m; i++) if (!to.startsWith(from.slice(0, i))) {
        a = i - 1;
        break;
    }
    let pub = from.slice(0, a);
    let len = pub.lastIndexOf("/") + 1;
    let k = from.slice(len);
    let ret = "";
    for (let i = 0; i < k.length; i++) if (k[i] === '/') ret += '../';
    return ret + to.slice(len);
}

export function commonDir(pathA:any, pathB:any) {
    if (pathA[0] === ".") pathA = pathA.slice(1);
    if (pathB[0] === ".") pathB = pathB.slice(1);
    pathA = pathA.replace(/\\/g, '/');
    pathB = pathB.replace(/\\/g, '/');
    let a = Math.min(pathA.length, pathB.length);
    for (let i = 1, m = Math.min(pathA.length, pathB.length); i <= m; i++) if (!pathA.startsWith(pathB.slice(0, i))) {
        a = i - 1;
        break;
    }
    let pub = pathB.slice(0, a);
    let len = pub.lastIndexOf("/") + 1;
    return pathA.slice(0, len);
}

export function commandExecute(cb:any, helper:any) {
    console.time("Total use");

    function endTime() {
        ioEvent.check(() => console.timeEnd("Total use"));
    }

    let orders:any[] = [];
    console.log(process.argv)
    for (let order of process.argv) if (order.startsWith("-")) orders.push(order.slice(1));
    let iter = process.argv[Symbol.iterator](), nxt = iter.next(), called = false, faster = orders.includes("f"),
        fastCnt: CntEvent;
    if (faster) {
        fastCnt = new CntEvent;
        fastCnt.add(endTime);
    }

    function doNext() {
        let nxt = iter.next();
        while (!nxt.done && nxt.value.startsWith("-")) nxt = iter.next();
        if (nxt.done) {
            if (!called) console.log("Command Line Helper:\n\n" + helper);
            else if (!faster) endTime();
        } else {
            called = true;
            if (faster) fastCnt.encount(), cb(nxt.value, fastCnt.decount, orders), doNext();
            else cb(nxt.value, doNext, orders);
        }
    }

    while (!nxt.done && !nxt.value.endsWith(".js")) nxt = iter.next();
    doNext();
}




// module.exports = {
//     mkdirs: mkdirs, get: get, save: save, toDir: toDir, del: del, addIO: ioEvent.add,
//     changeExt: changeExt, CntEvent: CntEvent, scanDirByExt: scanDirByExt, commonDir: commonDir,
//     commandExecute: commandExecute
// };
