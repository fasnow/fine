
import * as wu from "./wuLib"
import path from "path"
import UglifyJS from "uglify-es"
import {js_beautify} from "js-beautify"
import {VM} from 'vm2'

function jsBeautify(code:any) {
    return UglifyJS.minify(code, {mangle: false, compress: false, output: {beautify: true, comments: true}}).code;
}

function splitJs(name:any, cb:any, mainDir:any) {
    let isSubPkg = mainDir && mainDir.length > 0;
    let dir = path.dirname(name);
    if (isSubPkg) {
        dir = mainDir;
    }
    wu.get(name, (code:any) => {
        let needDelList:any = {};
        let vm = new VM({
            sandbox: {
                require() {
                },
                define(name:any, func:any) {
                    let code = func.toString();
                    code = code.slice(code.indexOf("{") + 1, code.lastIndexOf("}") - 1).trim();
                    let bcode = code;
                    if (code.startsWith('"use strict";') || code.startsWith("'use strict';")) code = code.slice(13);
                    else if ((code.startsWith('(function(){"use strict";') || code.startsWith("(function(){'use strict';")) && code.endsWith("})();")) code = code.slice(25, -5);
                    let res = jsBeautify(code);
                    if (typeof res == "undefined") {
                        console.log("Fail to delete 'use strict' in \"" + name + "\".");
                        res = jsBeautify(bcode);
                    }
                    console.log(dir, name);
                    needDelList[path.resolve(dir, name)] = -8;
                    wu.save(path.resolve(dir, name), jsBeautify(res));
                },
                definePlugin() {
                },
                requirePlugin() {
                }
            }
        });
        if (isSubPkg) {
            code = code.slice(code.indexOf("define("));
        }
        console.log('splitJs: ' + name);
        vm.run(code);
        console.log("Splitting \"" + name + "\" done.");
        if (!needDelList[name]) needDelList[name] = 8;
        cb(needDelList);
    });
}
export  {
    jsBeautify,
    js_beautify as wxsBeautify ,
    splitJs
}

if (require.main === module) {
    wu.commandExecute(splitJs, "Split and beautify weapp js file.\n\n<files...>\n\n<files...> js files to split and beautify.");
}
